ssm 整合
使用技术maven springboot-2.3.1 mysql-5.1.47 mybatis-2.1.3 thymeleaf html
student 学生类
classs  班级类
