/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80020
 Source Host           : localhost:3306
 Source Schema         : emp_manager

 Target Server Type    : MySQL
 Target Server Version : 80020
 File Encoding         : 65001

 Date: 14/07/2020 16:17:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `dept_id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `dept_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '部门名称',
  PRIMARY KEY (`dept_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '部门表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '人事部');
INSERT INTO `department` VALUES (2, '行政部');
INSERT INTO `department` VALUES (3, '产品研发部');

-- ----------------------------
-- Table structure for employee
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee`  (
  `emp_id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `emp_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工名',
  `dept_id` int NOT NULL COMMENT '关联部门表主键',
  `gender` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '性别',
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '邮箱',
  `phone` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '手机号',
  `hire_date` datetime(0) NULL DEFAULT NULL COMMENT '入职时间',
  PRIMARY KEY (`emp_id`) USING BTREE,
  INDEX `dept_id`(`dept_id`) USING BTREE,
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1009 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '员工表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO `employee` VALUES (1000, '阿茶', 1, '男', '1951511093@qq.com', '18647810373', '2020-07-01 23:32:27');
INSERT INTO `employee` VALUES (1001, '梅十三', 2, '女', '2237@qq.com', ' 12345678909', '2020-01-18 23:33:28');
INSERT INTO `employee` VALUES (1002, '汪疯', 1, '男', 'wang@163.com', '2444666661', '2019-06-06 08:20:00');
INSERT INTO `employee` VALUES (1007, '江主任', 1, '女', '122@163.com', '12332211233', '2019-09-09 10:26:30');
INSERT INTO `employee` VALUES (1008, '嗯嗯', 2, '男', '1951511093@qq.com', '18647810373', '2020-01-18 23:33:28');
INSERT INTO `employee` VALUES (1009, '嘎嘎嘎', 3, '女', '194949@qq.com', '1234754321', '2020-01-18 23:33:28');

SET FOREIGN_KEY_CHECKS = 1;
