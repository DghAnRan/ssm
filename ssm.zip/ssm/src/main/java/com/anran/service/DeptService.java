package com.anran.service;

import com.anran.entity.Department;

import java.util.List;
/**
 * @Author: 阿茶
 * @Company: Astra
 * @Current: 11:41
 * @Date: 2020/7/9
 */
public interface DeptService {

    /**
     * 获取部门列表
     * @return
     */
    List<Department> getDepartmentList();
}
