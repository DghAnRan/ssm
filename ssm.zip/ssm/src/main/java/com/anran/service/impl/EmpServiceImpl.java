package com.anran.service.impl;

import com.anran.entity.Employee;
import com.anran.mapper.EmployeeMapper;
import com.anran.service.EmpService;
import com.anran.uti.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class EmpServiceImpl implements EmpService {
    @Resource
    private EmployeeMapper employeeMapper;
    /*新增*/
    @Override
    public void addEmployee(Employee employee) {
        employeeMapper.addEmployee(employee);
    }
    /*根据ID删除*/
    @Override
    public void deleteEmployeeByEmpId(Integer empId) {
        employeeMapper.deleteEmployeeByEmpId(empId);
    }
    /*根据ID修改(更新)*/
    @Override
    public void updateEmployee(Employee employee) {
        employeeMapper.updateEmployee(employee);
    }
    /*分页查询使用的是GitHub的jar包*/
    @Override
    public Page<Employee> getEmployeeList(int pageNo, int pageSize) {
        Page<Employee> page = new Page<>();
        PageHelper.startPage(pageNo,pageSize);
        List<Employee> employeeList = employeeMapper.getEmployeeList();
        PageInfo<Employee> info = new PageInfo<>(employeeList);
        page.setPage(info.getList());
        page.setPageCount(info.getPages());
        page.setPageNo(info.getPageNum());
        page.setHasNext(info.isHasNextPage());
        page.setHasPre(info.isHasPreviousPage());

        return page;
    }
    /*修改的ID查询*/
    @Override
    public Employee getEmployeeByEmpId(Integer empId) {

        return employeeMapper.getEmployeeByEmpId(empId);
    }
    /*条件name查询搜索*/
    @Override
    public Employee AsearchQuery(String empName) {
        return employeeMapper.AsearchQuery("%"+empName+"%");
    }
}
