package com.anran.mapper;

import com.anran.entity.Department;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * @Author: 阿茶
 * @Company: Astra
 * @Current: 11:59
 * @Date: 2020/7/9
 */
@Mapper
public interface DepartmentMapper {
    /**
     * 获取部门列表
     * @return
     */
    List<Department> getDepartmentList();

    /**
     * 根据部门ID查询部门信息
     * @param deptId
     * @return
     */
    Department getDepartmentByDeptId(Integer deptId);


    /**
     * 根据部门ID查询部门详情
     * @param deptId
     * @return
     */
    Department getDepartmentByDeptId_(Integer deptId);

}
