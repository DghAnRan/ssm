package com.anran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * @Author: 阿茶
 * @Company: Astra
 * @Current: 18:48
 * @Date: 2020/7/1
 */
@SpringBootTest
class SsmApplicationTests {
	@Test
	void contextLoads() {
	}

}
